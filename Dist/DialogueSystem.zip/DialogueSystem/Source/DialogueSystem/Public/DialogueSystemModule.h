//Copyright (c) 2016 Artem A. Mavrin and other contributors

#pragma once

#define DIALOGUESYSTEM_MODULE_NAME "DialogueSystem"

#include "BTComposite_Context.h"

#include "ModuleManager.h"

//////////////////////////////////////////////////////////////////////////
// IDialogueSystemModule

class IDialogueSystemModule : public IModuleInterface
{
};
